import tensorflow as tf
import math
import time
import numpy as np
import os
import sys

from transform_nets import input_transform_net
from gat_layers import attn_feature
import tf_util1


def placeholder_inputs(batch_size, num_point):
    pointclouds_pl = tf.placeholder(tf.float32,
                                    shape=(batch_size, num_point, 3))
    labels_pl = tf.placeholder(tf.int32,
                               shape=(batch_size, num_point))
    return pointclouds_pl, labels_pl


def get_model(point_cloud, is_training, bn_decay=None):

    batch_size = point_cloud.get_shape()[0].value
    num_point = point_cloud.get_shape()[1].value
    end_points = {}
    k = 20
    adj_matrix = tf_util1.pairwise_distance(point_cloud)
    nn_idx = tf_util1.knn(adj_matrix, k=k)
    n_heads = 1
    attns = []
    neighbors = []
    for i in range(n_heads):
        attns_feature, coefs, neighbor_feature = attn_feature(point_cloud, 16, nn_idx, activation=tf.nn.elu,
                                                   is_training=is_training, bn_decay=bn_decay,
                                                   layer='layer0', k=k, i=i, is_dist=True)
        attns.append(attns_feature)
        neighbors.append(neighbor_feature)
    attention_features = tf.concat(attns, axis=-1)
    net0 = attention_features

    with tf.variable_scope('transform_net1') as sc:
        transform = input_transform_net(net0, is_training, bn_decay, K=3)

    point_cloud_transformed = tf.matmul(point_cloud, transform)

    adj_matrix = tf_util1.pairwise_distance(point_cloud_transformed)
    nn_idx = tf_util1.knn(adj_matrix, k=k)
    n_heads = 4
    attns = []
    neighbors = []
    for i in range(n_heads):
        attns_feature, coefs, neighbor_feature = attn_feature(point_cloud_transformed, 16, nn_idx, activation=tf.nn.elu,
                                                              is_training=is_training, bn_decay=bn_decay,
                                                              layer='layer1', k=k, i=i)
        attns.append(attns_feature)
        neighbors.append(neighbor_feature)

    attention_features1 = tf.concat(attns, axis=-1)
    net1 = attention_features1

    adj_matrix = tf_util1.pairwise_distance(net1)
    nn_idx = tf_util1.knn(adj_matrix, k=k)
    n_heads = 4
    attns = []
    neighbors = []
    for i in range(n_heads):
        attns_feature, coefs, neighbor_feature = attn_feature(net1, 16, nn_idx, activation=tf.nn.elu,
                                                    is_training=is_training, bn_decay=bn_decay,
                                                    layer='layer2', k=k, i=i)
        attns.append(attns_feature)
        neighbors.append(neighbor_feature)

    attention_features2 = tf.concat(attns, axis=-1)
    net2 = attention_features2 + net1

    adj_matrix = tf_util1.pairwise_distance(net2)
    nn_idx = tf_util1.knn(adj_matrix, k=k)
    n_heads = 4
    attns = []
    locals = []
    for i in range(n_heads):
        attns_feature, coefs, neighbor_feature = attn_feature(net2, 16, nn_idx, activation=tf.nn.elu,
                                                              is_training=is_training, bn_decay=bn_decay,
                                                              layer='layer3', k=k, i=i)
        attns.append(attns_feature)
        #locals.append(neighbor_feature)

    attention_features3 = tf.concat(attns, axis=-1)
    net3 = attention_features3 + net2

    net3 = tf_util1.conv2d(net3, 128, [1, 1], padding='VALID',
                          stride=[1, 1],
                          bn=True, is_training=is_training, scope='gaanet4', bn_decay=bn_decay, is_dist=True)

    net = tf_util1.conv2d(tf.concat([net1, net2, net3], axis=-1), 1024, [1, 1],
                         padding='VALID', stride=[1, 1],
                         bn=True, is_training=is_training,
                         scope='gaanet5', bn_decay=bn_decay)

    net_max = tf.reduce_max(net, axis=1, keep_dims=True)
	
    expand = tf.tile(net_max, [1, num_point, 1, 1])

    concat = tf.concat(axis=3, values=[expand,
                                       net1,
                                       net2,
                                       net3
                                       ])

    net = tf_util1.conv2d(concat, 512, [1, 1], padding='VALID', stride=[1, 1],
                         bn=True, is_training=is_training, scope='conv1', is_dist=True)
    net = tf_util1.conv2d(net, 256, [1, 1], padding='VALID', stride=[1, 1],
                         bn=True, is_training=is_training, scope='conv2', is_dist=True)
    net = tf_util1.dropout(net, keep_prob=0.7, is_training=is_training, scope='dp1')
    net = tf_util1.conv2d(net, 9, [1, 1], padding='VALID', stride=[1, 1],
                         activation_fn=None, scope='conv3', is_dist=True)
    net = tf.squeeze(net, [2])
    return net


def get_loss(pred, label):
    """ pred: B,N,8; label: B,N """
    alpha = [[0.96, 0.46, 0.98, 0.93, 0.72, 0.99, 0.99, 0.94, 0.99]]
    loss = adaptive_loss(pred, label, alpha_okland, gamma=2)
    return loss


def adaptive_loss(logits, label, alpha, gamma):
    epsilon = 1.e-8
    n_classes = 9
    y_true = tf.one_hot(label, n_classes)
    probs = tf.nn.softmax(logits)
    y_pred = tf.clip_by_value(probs, epsilon, 1. - epsilon)

    if gamma == 0:
        weight = tf.cast(1, tf.float32)
    else:
        weight = tf.pow(alpha, gamma)
		
    xent = tf.multiply(y_true, -tf.log(y_pred))
    adaptive_xent = tf.multiply(weight, xent)

    reduced_fl = tf.reduce_sum(adaptive_xent, axis=-1)
    return tf.reduce_mean(reduced_fl)

def count_flops(graph):
    flops = tf.profiler.profile(graph, options=tf.profiler.ProfileOptionBuilder.float_operation())
    params = tf.profiler.profile(graph, options=tf.profiler.ProfileOptionBuilder.trainable_variables_parameter())
    print('FLOPs: {};   Trainable params: {}'.format(flops.total_float_ops, params.total_parameters))

if __name__=='__main__':
  batch_size = 2
  num_pt = 124
  pos_dim = 3

  input_feed = np.random.rand(batch_size, num_pt, pos_dim)
  label_feed = np.random.rand(batch_size)
  label_feed[label_feed>=0.5] = 1
  label_feed[label_feed<0.5] = 0
  label_feed = label_feed.astype(np.int32)

  # # np.save('./debug/input_feed.npy', input_feed)
  # input_feed = np.load('./debug/input_feed.npy')
  # print input_feed

  with tf.Graph().as_default() as graph:
    input_pl, label_pl = placeholder_inputs(batch_size, num_pt)
    is_training_pl = tf.placeholder(tf.bool, shape=())
    pos = get_model(input_pl, is_training_pl)
    # loss = get_loss(logits, label_pl, None)
    count_flops(graph)

    with tf.Session() as sess:
      sess.run(tf.global_variables_initializer())
      feed_dict = {input_pl: input_feed, label_pl: label_feed}
      res1, res2 = sess.run([pos], feed_dict=feed_dict)
      print(res1.shape)
      print(res1)

      print(res2.shape)
      print(res2)
