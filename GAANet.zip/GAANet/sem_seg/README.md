## Semantic segmentation of large-scale outdoor scenes

### Dataset

1. Download original Toronto3D MLS dataset (<a href="https://github.com/WeikaiTan/Toronto-3D#results">Toronto3D Dataset</a>) for testing and visualization.

2. Prepared HDF5 data like S3DIS data processed by the DGCNN for training:

to generate "sem_seg/toronto3D_data"

### Train

We keep using 1 GPUs for model training. To train the model, run
```
python train_toronto3D_GAANet.py
```

### Evaluation

1. We choose the second section of the dataset as testing set. To get predicted results, run 
```
python batch_inference_toronto3D.py
```
2. To obtain overall quantitative evaluation results, run
```
python eval_iou_accuracy.py
```
