import tensorflow as tf

import os
import sys
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
sys.path.append(BASE_DIR)
sys.path.append(ROOT_DIR)
sys.path.append(os.path.join(ROOT_DIR, 'utils'))
import tf_util1
import numpy as np



def attn_feature(input_feature, output_dim, neighbors_idx, activation, in_dropout=0.0, coef_dropout=0.0, is_training=None, bn_decay=None, layer='', k=20, i=0, is_dist=False):

    batch_size = input_feature.get_shape()[0].value

    input_feature = tf.squeeze(input_feature)
    if batch_size == 1:
        input_feature = tf.expand_dims(input_feature, 0)

    input_feature = tf.expand_dims(input_feature, axis=-2)

    neighbors = tf_util1.get_neighbors(input_feature, nn_idx=neighbors_idx, k=k)
    input_feature_tiled = tf.tile(input_feature, [1, 1, k, 1])
    edge_feature = input_feature_tiled - neighbors
    edge_feature_weight = gaussian(edge_feature)
    weighted_edge_feature = edge_feature * edge_feature_weight

    weighted_edge_feature = tf_util1.conv2d(weighted_edge_feature, output_dim, [1, 1], padding='VALID', stride=[1, 1],
                               bn=True, is_training=is_training, scope=layer + '_edgefea_' + str(i), bn_decay=bn_decay, is_dist=is_dist)

    neighbor_feature = tf.reduce_max(weighted_edge_feature, axis=-2, keep_dims=True)

    Q1 = tf_util1.conv2d(input_feature, output_dim, [1, 1], padding='VALID', stride=[1, 1],
                        bn=True, is_training=is_training, scope=layer + 'query_self' + str(i), bn_decay=bn_decay,
                        is_dist=is_dist)
    K1 = tf_util1.conv2d(input_feature, output_dim, [1, 1], padding='VALID', stride=[1, 1],
                        bn=True, is_training=is_training, scope=layer + 'key_self' + str(i), bn_decay=bn_decay,
                        is_dist=is_dist)
    V1 = tf_util1.conv2d(input_feature, output_dim, [1, 1], padding='VALID', stride=[1, 1],
                        bn=True, is_training=is_training, scope=layer + 'value_self' + str(i), bn_decay=bn_decay,
                        is_dist=is_dist)

    logits1 = tf.matmul(Q1, K1, transpose_b=True)
    logits1 = tf.contrib.layers.bias_add(logits1, scope=layer + 'bias_self' + str(i))
    weights1 = tf.nn.softmax(logits1, name=layer + "attention_weights1" + str(i))
    if is_training is not None:
        weights1 = tf.nn.dropout(weights1, 0.5)
    self_attention_features = tf.matmul(weights1, V1)
    attention_feature = self_attention_features + neighbor_feature

    return attention_feature, weights1, edge_feature


def gaussian(dist, a=1, b=0, c=1):
    return a * np.math.e ** (-(dist - b) ** 2 / (2 * c ** 2))
